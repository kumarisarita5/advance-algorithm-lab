#include <bits/stdc++.h>
using namespace std;

bool search(int key, vector<int>& fr)
{
    for (int i = 0; i < fr.size(); i++)
        if (fr[i] == key)
            return true;
    return false;
}

int predict(int pg[], vector<int>& fr, int pn, int index)
{
    int res = -1, farthest = index;
    for (int i = 0; i < fr.size(); i++)
    {
        int j;
        for (j = index; j < pn; j++)
        {
            if (fr[i] == pg[j])
            {
                if (j > farthest)
                {
                    farthest = j;
                    res = i;
                }
                break;
            }
        }
        if (j == pn)
            return i;
    }
    return (res == -1) ? 0 : res;
}

void OP(int pg[], int pn, int fn)
{

    vector<int> fr;
    int hit = 0;
    for (int i = 0; i < pn; i++)
    {
        if (search(pg[i], fr))
        {
            hit++;
            continue;
        }
        if (fr.size() < fn)
            fr.push_back(pg[i]);
        else
        {
            int j = predict(pg, fr, pn, i + 1);
            fr[j] = pg[i];
        }
    }
    cout << "No. of Page Faults : " << pn - hit << endl;
}

// Driver Function
int main()
{
    int n,c;
    string s;
    cout << "Enter Page References String:\n";
    cin >> s;
    n=s.length();
    int pg[n];
    for(int i=0;i<n;i++)
        pg[i]=s[i]-'0';
    cout << "Enter no. of Page Frames:\n";
    cin >> c;
    OP(pg,n,c);
    return 0;
}
