#!/bin/sh
echo "Enter number of terms"
read n
x=1
y=1
z=2
i=3
echo "Tribonacci Terms upto $n terms:"
echo $x
echo $y
echo $z
while [ $i -lt $n ]
do
	i=`expr $i + 1`
	w=`expr $x + $y + $z`
	echo $w
	x=$y
	y=$z
	z=$w
done
