#!/bin/sh
file1=$1
file2=$2
touch $file1
touch $file2
chmod 555 $file1	#Read_Only
chmod 777 $file2	#Read_And_Write

