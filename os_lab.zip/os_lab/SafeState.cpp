#include<bits/stdc++.h>
using namespace std;

#define P 10    // Max Process
#define R 10    // Max Resources

int total = 0;

bool is_available(int process_id, int allocated[][R], int max[][R],
int need[][R], int available[], int p, int r)
{

    bool flag = true;
    for (int i = 0; i < r; i++)
        if (need[process_id][i] > available[i])
            flag = false;

    return flag;
}

void safe_sequence(bool marked[], int allocated[][R], int max[][R],
int need[][R], int available[], vector<int> safe, int p, int r)
{

    for (int i = 0; i < p; i++)
    {
        if (!marked[i] && is_available(i, allocated, max, need,
available, p, r))
        {

            marked[i] = true;
            for (int j = 0; j < r; j++)
                available[j] += allocated[i][j];

            safe.push_back(i);
            safe_sequence(marked, allocated, max, need, available, safe, p, r);
            safe.pop_back();

            marked[i] = false;
            for (int j = 0; j < r; j++)
                available[j] -= allocated[i][j];
        }
    }
    if (safe.size() == p)
    {
        total++;
        for (int i = 0; i < p; i++)
        {
            cout << "P" << safe[i] + 1;
            if (i != (p - 1))
                cout << "--> ";
        }
        cout << endl;
    }
}

int main()
{
    int allocated[P][R],max[P][R],resources[R],available[R];
    int p,r;
    cout << "Enter Number of Processes and Resources:\n";
    cin >> p >> r;

    cout << "\nEnter Total Available Resources:\n";
    for(int i=0;i<r;i++)
        cin >> resources[i];

    cout << "\nEnter Allocated Resources Matrix\n";
    for(int i=0;i<p;i++)
        for(int j=0;j<r;j++)
            cin >> allocated[i][j];

    cout << "\nEnter Maximum Nedd of Resources Matrix\n";
    for(int i=0;i<p;i++)
        for(int j=0;j<r;j++)
            cin >> max[i][j];

    for (int i = 0; i < r; i++)
    {
        int sum = 0;
        for (int j = 0; j < p; j++)
            sum += allocated[j][i];
        available[i] = resources[i] - sum;
        //cout << available[i] << " ";
    }

    vector<int> safe;

    bool marked[P];
    memset(marked, false, sizeof(marked));

    int need[P][R];
    for (int i = 0; i < p; i++)
        for (int j = 0; j < r; j++)
            need[i][j] = max[i][j] - allocated[i][j];

    cout << "\nSafe sequences are:" << endl;
    safe_sequence(marked, allocated, max, need, available, safe, p, r);

    cout << "\nThere are total " << total << " safe-sequences" << endl;
    return 0;
}
