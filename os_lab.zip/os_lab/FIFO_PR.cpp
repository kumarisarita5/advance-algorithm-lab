#include<bits/stdc++.h>
using namespace std;

int PF(int p[], int n, int c)
{
    set<int> s;
    queue<int> Q;

    int pf=0;
    for (int i=0; i<n; i++)
    {
        if (s.size() < c)
        {
            if (s.find(p[i])==s.end())
            {
                s.insert(p[i]);
                pf++;
                Q.push(p[i]);
            }
        }
        else
        {
            if (s.find(p[i]) == s.end())
            {
                int val=Q.front();
                Q.pop();
                s.erase(val);
                s.insert(p[i]);
                Q.push(p[i]);
                pf++;
            }
        }
    }
    return pf;
}

int main()
{
    int n,c;
    string s;
    cout << "Enter Page References String:\n";
    cin >> s;
    n=s.length();
    int pg[n];
    for(int i=0;i<n;i++)
        pg[i]=s[i]-'0';
    cout << "Enter no. of Page Frames:\n";
    cin >> c;
    cout << "Number of Faults : " << PF(pg,n,c) << endl;
    return 0;
}
