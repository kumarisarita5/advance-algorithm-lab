#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

void main()
{
	pid_t p;
	p = fork();
	printf("fork demo:\n");
	if(p==0)
	{
		printf("Child:\nId = %d\nParent Id = %d\n", getpid(), getppid());
		printf("pid = %d\n", p);
	}
	else
	{
		printf("Parent:\nId = %d\nParent Id = %d\n", getpid(), getppid());
		printf("pid = %d\n", p);
	}
}
