#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

void main()
{
	int i=0;
	char s[7] = "Anchal";
	for(i=0;i<6;i++)
	{
		printf("%c \n", s[i]);
		fflush(stdout);
		if(i < 5)
		sleep(i+1);
	}
	printf("\n");
}
