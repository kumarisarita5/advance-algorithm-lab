#
a=1
while [ 1 -eq 1 ]
do
	read cmd
	case "$cmd" in
	"dir")
		ls
		;;
	"cd")
		cd
		;;
	"rename")
		echo Enter Old File Name
		read f
		echo Ente new File name
		read n
		mv $f $n
		;;
	"delete")
		echo Enter File name to be deleted
		read r
		rm $r 
		;;
	"copy")
		echo Enter Source File Name
		read s
		echo Enter Destination File Name
		read d
		cp $s $d 
		;;
	"exit")
		break 
		;;
	*)
		echo No Match
		;;
	esac
done
