
A=5
echo $A
B=6
Z=9
C=`expr $A \* $B`
echo $C
D=`expr $Z / $A`
E=`expr $C + $D`
echo $E
echo $D
