#include<bits/stdc++.h>
using namespace std;

struct process
{
    int ID,AT,BT,Q,FT,TAT,WT;
};

int main()
{
    int n,p;
    cout<<"Enter number of processes: ";
    cin >> n;
    process arr[n+1];
    int rt[n+1];
    queue<int> q1,q2,q3;
    q1.push(-1);
    q2.push(-1);
    q3.push(-1);
    int qnt1=4,qnt2=8,qnt3=12;
    cout<<"Enter Arrival Time, Burst Time and Queue No. for the processes: "<<endl;
    for(int i=1;i<=n;i++)
    {
        arr[i].ID=i;
        cin >> arr[i].AT; // Arrival Time
        cin >> arr[i].BT; // Burst Time
        cin >> arr[i].Q; // Queue No.
        rt[i]=arr[i].BT;
    }
    int t=0,j=1,a=0;
    cout << endl;
    while(!q1.empty())
    {
        if(arr[j].AT==t && j<=n)
        {
            if(arr[j].Q==1)
                q1.push(j);
            else if(arr[j].Q==2)
                q2.push(j);
            else
                q3.push(j);
            cout << "Process " << j << " added in Queue " << arr[j].Q
<< " at time " << t << endl;
            j++;
        }
        //t++;
        if(a==0)
        {
            p=q1.front();
            if(p==-1)
            {
                q1.pop();
                if(q1.empty())
                {
                    q1.push(-1);
                    t++;
                }
                //t++;
                continue;
            }
            cout << "CURRENTLY PROCESSING PROCESS " << p << " in queue " << arr[p].Q <<  endl;
            a=1;
        }

        int k=rt[p], l=qnt1;
        while(k!=0 && l!=0)
        {
            t++;
            k--;
            l--;
            if(arr[j].AT==t  && j<=n)
            {
                if(arr[j].Q==1)
                    q1.push(j);
                else if(arr[j].Q==2)
                    q2.push(j);
                else
                    q3.push(j);
                cout << "Process " << j << " added in Queue " << arr[j].Q << " at time " << t << endl;
                j++;
            }
        }
        rt[p]=k;
        //cout << rt[p] << endl;
        if(rt[p]==0)
        {
            q1.pop();
            a=0;
            arr[p].FT=t;
            cout << "Process " << p << " completed at time " << t << endl;
        }
        else
        {
            q1.pop();
            q2.push(p);
            arr[p].Q=2;
            cout << "Process " << p << " moved from Queue 1 to Queue 2 at time " << t << endl;
            a=0;
        }
    }

    cout << "\n\n*********************QUEUE 1 COMPLETED*********************\n";
    a=0;
    while(!q2.empty())
    {
        if(arr[j].AT==t && j<=n)
        {
            if(arr[j].Q==1)
                q1.push(j);
            else if(arr[j].Q==2)
                q2.push(j);
            else
                q3.push(j);
            cout << "Process " << j << " added in Queue " << arr[j].Q << " at time " << t << endl;
            j++;
        }
        //t++;
        if(a==0)
        {
            p=q2.front();
            if(p==-1)
            {
                q2.pop();
                if(q2.empty())
                {
                    q2.push(-1);
                    t++;
                }
                //t++;
                continue;
            }
            cout << "CURRENTLY PROCESSING PROCESS " << p <<" in queue " << arr[p].Q << endl;
            a=1;
        }

        int k=rt[p], l=qnt2;
        while(k!=0 && l!=0)
        {
            t++;
            k--;
            l--;
            if(arr[j].AT==t && j<=n)
            {
                if(arr[j].Q==1)
                    q1.push(j);
                else if(arr[j].Q==2)
                    q2.push(j);
                else
                    q3.push(j);
                cout << "Process " << j << " added in Queue " << arr[j].Q << " at time " << t << endl;
                j++;
            }
        }
        rt[p]=k;
        if(rt[p]==0)
        {
            q2.pop();
            a=0;
            arr[p].FT=t;
            cout << "Process " << p << " completed at time " << t << endl;
        }
        else
        {
            q2.pop();
            q3.push(p);
            arr[p].Q=3;
            cout << "Process " << p << " moved from Queue 2 to Queue 3 at time " << t << endl;
            a=0;
        }
    }

    cout << "\n\n*********************QUEUE 2 COMPLETED*********************\n";
    a=0;
    while(!q3.empty())
    {
        if(arr[j].AT==t && j<=n)
        {
            if(arr[j].Q==1)
                q1.push(j);
            else if(arr[j].Q==2)
                q2.push(j);
            else
                q3.push(j);
            cout << "Process " << j << " added in Queue " << arr[j].Q << " at time " << t << endl;
            j++;
        }
        //t++;
        if(a==0)
        {
            p=q3.front();
            if(p==-1)
            {
                q3.pop();
                if(q3.empty())
                {
                    q3.push(-1);
                    t++;
                }
                continue;
            }
            cout << "CURRENTLY PROCESSING PROCESS " << p << " in queue " << arr[p].Q <<  endl;
            a=1;
        }

        int k=rt[p], l=qnt3;
        while(k!=0 && l!=0)
        {
            t++;
            k--;
            l--;
            if(arr[j].AT==t && j<=n)
            {
                if(arr[j].Q==1)
                    q1.push(j);
                else if(arr[j].Q==2)
                    q2.push(j);
                else
                    q3.push(j);
                cout << "Process " << j << " added in Queue " << arr[j].Q << " at time " << t << endl;
                j++;
            }
        }
        rt[p]=k;
        if(rt[p]==0)
        {
            q3.pop();
            a=0;
            arr[p].FT=t;
            cout << "Process " << p << " completed at time " << t << endl;
            p=q3.front();
            if(p==-1)
            {
                q3.pop();
                if(q3.empty())
                {
                    break;
                }
                continue;
            }
        }
        else
        {
            q3.pop();
            q3.push(p);
            arr[p].Q=3;
            cout << "Process " << p << " moved from front of Queue 3 to back of Queue 3 at time " << t << endl;
            a=0;
        }
    }

    cout << "\n\n*********************QUEUE 3 COMPLETED*********************\n";
    double s=0,r=0;
    cout << "\n\nPROCESS ID\t" << "AT\t" << "BT\t" << "CT\t" << "TAT\t" << "WT\n";
    for(int i=1;i<=n;i++)
    {
        arr[i].TAT=arr[i].FT-arr[i].AT;
        arr[i].WT=arr[i].TAT-arr[i].BT;
        s+=arr[i].TAT;
        r+=arr[i].WT;
        cout << arr[i].ID << "\t\t" << arr[i].AT << "\t" << arr[i].BT << "\t" << arr[i].FT << "\t" << arr[i].TAT << "\t" << arr[i].WT << endl;

    }
    cout << "Average TAT:\t" << s/n << endl;
    cout << "Average WT :\t" << r/n << endl;
}

/*
7
0 4 1
0 3 1
1 8 1
2 7 1
3 14 1
4 9 1
10 22 1

*/
