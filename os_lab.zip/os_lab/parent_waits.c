#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void main()
{
	pid_t p;
	p = fork();
	if(p==0)
	{
		printf("Child: \nId = %d\nParent Id = %d\n", getpid(), getppid());
	}
	else
	{
		printf("WAIT...\n");
		pid_t cpid = wait(NULL);
		printf("Parent: \nId = %d\nChild Id = %d\n", getpid(), cpid);
	}
}
