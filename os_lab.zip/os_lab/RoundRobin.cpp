#include<bits/stdc++.h>
using namespace std;

struct process
{
    int ID,AT,BT,FT,TAT,WT;
};
bool comp(process a, process b)
{
    if(a.AT<b.AT)
        return true;
    return a.ID<b.ID;
}
int main()
{
    double m;
    int n,tq,bt=0,t,i;
    cout<<"Enter number of processes: ";
    cin >> n;
    m=n;
    process arr[n];
    int wt[n];
    for(int i=0;i<n;i++)
    {
        arr[i].ID=i+1;
        cin >> arr[i].AT;
        cin >> arr[i].BT;
    }
    cout<<"Enter time quantum: ";
    cin >> tq;
    bt=0;
    queue<process> q;
    sort(arr,arr+n,comp);
    q.push(arr[0]);
    t=arr[0].AT;
    i=1;
    while(1)
    {
        process z;
        bool f=0;
        if(q.empty())
        {
            if(i==n)
                break;
            else
                t++;
        }
        else
        {
            z=q.front();
            q.pop();
            if(t<z.AT)
                t=z.AT;
            if(z.BT<=tq)
            {
                t+=z.BT;
                bt+=(t-z.AT);
                arr[z.ID-1].FT=t;
            }
            else
            {
                z.BT=z.BT-tq;
                t+=tq;
                f=1;
            }
        }
        while(i<n && t>=arr[i].AT)
            q.push(arr[i++]);
        if(f)
            q.push(z);
    }
    double avgTAT=0,avgWT=0;
    for(int i=0;i<n;i++)
    {
        arr[i].TAT=arr[i].FT-arr[i].AT;
        arr[i].WT=arr[i].TAT-arr[i].BT;
        avgTAT+=arr[i].TAT;
        avgWT+=arr[i].WT;
    }
    cout << "PROCESS ID\t" << "AT\t" << "BT\t" << "CT\t" << "TAT\t" << "WT\n";
    int c=0;
    for(int i=0;i<n;i++)
    {
        cout << arr[i].ID << "\t\t" << arr[i].AT << "\t" << arr[i].BT << "\t" << arr[i].FT << "\t" << arr[i].TAT << "\t" << arr[i].WT << endl;
    }

    cout << "Average TAT :\t" << avgTAT/m << endl;
    cout << "Average WT  :\t" << avgWT/m << endl;
    return 0;
}
