#include<bits/stdc++.h>
using namespace std;

struct process
{
    int ID,AT,BT,FT,TAT,WT;
};
bool comp(process a, process b)
{
    if(a.AT<b.AT)
        return true;
    return a.ID<b.ID;
}
int main()
{
    double m;
    int n;
    cout<<"Enter number of processes: ";
    cin >> n;
    m=n;
    process arr[n];
    int wt[n];
    cout<<"Enter arrival time and burst times for the processes: "<<endl;
    for(int i=0;i<n;i++)
    {
        arr[i].ID=i+1;
        cin >> arr[i].AT;
        cin >> arr[i].BT;
    }
    int rt[n];
    for(int i=0;i<n;i++)
        rt[i]=arr[i].BT;

    int complete=0,t=0,maxm=INT_MIN;
    int longest=0,finish_time;
    bool check=false;

    while(complete!=n)
    {
        for(int j=0;j<n;j++)
        {
            if((arr[j].AT<=t) && (rt[j]>maxm) && rt[j]>0)
            {
                maxm=rt[j];
                longest=j;
                check=true;
            }
        }

        if(check==false)
        {
            t++;
            continue;
        }
        rt[longest]--;
        maxm=rt[longest];
        if(maxm==0)
            maxm=INT_MIN;
        if(rt[longest]==0)
        {
            complete++;
            finish_time=t+1;
            arr[longest].FT=finish_time;
            /*wt[shortest]=finish_time-arr[shortest].BT-arr[shortest].BT;
            if(wt[shortest]<0)
                wt[shortest]=0;*/
        }
        t++;
    }
    double avgTAT=0,avgWT=0;
    for(int i=0;i<n;i++)
    {
        arr[i].TAT=arr[i].FT-arr[i].AT;
        arr[i].WT=arr[i].TAT-arr[i].BT;
        avgTAT+=arr[i].TAT;
        avgWT+=arr[i].WT;
    }
    cout << "PROCESS ID\t" << "AT\t" << "BT\t" << "CT\t" << "TAT\t" << "WT\n";
    int c=0;
    for(int i=0;i<n;i++)
    {
        cout << arr[i].ID << "\t\t" << arr[i].AT << "\t" << arr[i].BT << "\t" << arr[i].FT << "\t" << arr[i].TAT << "\t" << arr[i].WT << endl;
    }

    cout << "Average TAT :\t" << avgTAT/m << endl;
    cout << "Average WT  :\t" << avgWT/m << endl;
    return 0;
}
