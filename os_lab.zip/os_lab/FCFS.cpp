#include<bits/stdc++.h>
using namespace std;
struct ptime
{
    int pid;
    int atime;
    int btime;
};
bool compare(ptime p1,ptime p2)
{
    if(p1.atime==p2.atime) 
            return bool(p1.pid<p2.pid);
    else return bool(p1.atime<p2.atime);
}
void fcfs(ptime P[],int n)
{
    sort(P+1,P+n+1,compare);
	int t=0;
    int tat[n+1];int ctat=0;
    int sum = 0;
    int ct[n+1];
    int wt[n+1];
    for(int i=1;i<n+1;i++)
    {
        if(t>=P[i].atime)
        {
            t+=P[i].btime;
            ct[i] = t;
            tat[i]=t-P[i].atime;
            ctat+=tat[i];
            wt[i] = tat[i] - P[i].btime;
            sum+= wt[i];
        }    
        else
        t++;
    }
    for(int i=1;i<n+1;i++)
    {
        cout<<"Pid:\t"<<P[i].pid<<" AT:\t"<<P[i].atime<<"BT:\t"<<P[i].btime<<"CT:\t"<<ct[i]<<"TAT:\t"<<tat[i];
        cout<<"CT:\t"<<wt[i]<<"\n";
    }
    cout<<(float)ctat/n<<endl;
    cout<<"Average Waiting Time: "<<(1.0*sum/n)<<endl;
}
int main()
{
    int n;
    cout<<"Enter the no. of processes:";
    cin>>n;
    ptime P[n+1];
    for(int i=1;i<n+1;i++)
    {
        P[i].pid=i;
        cin>>P[i].atime>>P[i].btime;
    }
    fcfs(P,n);
}
