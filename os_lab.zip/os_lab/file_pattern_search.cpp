﻿#include<bits/stdc++.h>
using namespace std;
int main()
{
char fn[10],pat[10];
string temp="";
FILE *fp;
char ch;
printf("Enter file name\n");
scanf("%s",fn);
printf("Enter pattern to be searched\n");
scanf("%s",pat);
fp=fopen(fn,"r");
fscanf(fp,"%c",ch);
while(ch=!EOF)
{
//fgets(temp,1000,fp);
fscanf(fp,"%c",&ch);
if(ch!=' ')
temp+=ch;
else
{
if(strcmp(temp,pat)==0)
printf("pattern matched");
}
}
fclose(fp);
}
