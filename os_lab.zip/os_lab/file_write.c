﻿#include <stdio.h>

int main(){
	FILE *ptr=fopen("newfile.txt","a+");
	fprintf(ptr,"I am writing\n");
	char rd[150];
	int red;
	fclose(ptr);
	ptr=fopen("newfile.txt","a+");
	fscanf(ptr,"%[^/n]s",rd);
	printf("string: %s\nInteger: %d\n",rd,red);
}
