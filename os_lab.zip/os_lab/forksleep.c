#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

void main()
{
	pid_t p;
	p = fork();
	if(!p)
	{
		printf("Child: \nId = %d\nParent Id = %d\n", getpid(), getppid());
		printf("SLEEPING...\n");
		sleep(5);
		printf("Child: \nId = %d\nParent Id = %d\n", getpid(), getppid());
	}
	else
	{
		printf("SLEEping...\n");
		sleep(10);
		printf("PARENT HERE\nId = %d\n", getpid());
	}
}
