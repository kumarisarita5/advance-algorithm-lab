using namespace std;
#include<bits/stdc++.h>

void allocate(vector<vector<int> >need, vector<int>avail, vector<int>r)
{
int i, j, k;
bool f=1;
for(k=0;k<need.size();k++)
{
for(i=0;i<r.size();i++)
{
f=f&&(r[i]<need[k][i]);
if(f)
{
bool g=1;
for(j=0;j<r.size();j++)
{
g=g && (r[j]<=avail[j]);
}
if(g)
{
cout<<"Process can be allocated now"<<endl;
return ;
}
else
{
cout<<"Process can be allocated after process "<<k<<endl;
return ; 
}
}
}
}
}
int main()
{
vector<vector<int> >all={{0, 0, 1}, {3, 2, 0}, {2, 1, 1} };
vector<vector<int> >max={{8, 4, 3}, {6, 2, 0}, {3, 3, 3}};
vector<int>avail={3, 2, 2};

int i, j, n=all.size(), m=all[0].size();

vector<vector<int> >need(n, vector<int>(m));

for(int i=0;i<n;i++)
{
 for(int j=0;j<m;j++)
 {
 need[i][j]=max[i][j]-all[i][j];
 }
}

vector<int>r1={0, 0, 2}, r2{4, 0, 0};
allocate(need, avail, r1);
allocate(need, avail, r2);
return 0;
}
