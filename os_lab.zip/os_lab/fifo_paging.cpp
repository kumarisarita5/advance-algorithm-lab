#include<bits/stdc++.h>
using namespace std; 
int main(){
	int n;
	cin>>n;
	int a[n];
	for(int i=0;i<n;i++)cin>>a[i]; 
	int t;
	cin>>t;
	int b[t];
	for(int i=0;i<t;i++)b[i]=0;
	int k=0;
	int x=0;
	for(int i=0;i<n;i++){
		bool add=0;
		for(int j=0;j<t;j++){
			if(a[i]==b[j]){
				add=1;
				break;
			}
			if(b[j]==0){
				b[j]=a[i];
				k++;
				add=1;
				break;
			}
		}
		if(add==1)continue;
		k++;
		b[x]=a[i];
		x=(x+1)%t;
	}
	cout<<k<<endl;
}
