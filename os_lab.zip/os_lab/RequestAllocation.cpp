#include<bits/stdc++.h>
using namespace std;

#define P 10    // Max Process
#define R 10    // Max Resources

int total;

bool is_available(int process_id, int allocated[][R], int max[][R], int need[][R], int available[], int p, int r)
{

    bool flag = true;
    for (int i = 0; i < r; i++)
        if (need[process_id][i] > available[i])
            flag = false;

    return flag;
}

void safe_sequence(bool marked[], int allocated[][R], int max[][R], int need[][R], int available[], vector<int> safe, int p, int r)
{

    for (int i = 0; i < p; i++)
    {
        if (!marked[i] && is_available(i, allocated, max, need, available, p, r))
        {

            marked[i] = true;
            for (int j = 0; j < r; j++)
                available[j] += allocated[i][j];

            safe.push_back(i);
            safe_sequence(marked, allocated, max, need, available, safe, p, r);
            safe.pop_back();

            marked[i] = false;
            for (int j = 0; j < r; j++)
                available[j] -= allocated[i][j];
        }
    }
    if (safe.size() == p)
    {
        total+=1;
        for (int i = 0; i < p; i++)
        {
            cout << "P" << safe[i];
            if (i != (p - 1))
                cout << "--> ";
        }
        cout << endl;
    }
}

int main()
{
    int allocated[P][R],max[P][R],resources[R],available[R];
    int p,r;
    cout << "Enter Number of Processes and Resources:\n";
    cin >> p >> r;

    cout << "\nEnter Allocated Resources Matrix\n";
    for(int i=0;i<p;i++)
        for(int j=0;j<r;j++)
            cin >> allocated[i][j];

    cout << "\nEnter Maximum Need of Resources Matrix\n";
    for(int i=0;i<p;i++)
        for(int j=0;j<r;j++)
            cin >> max[i][j];

    cout << "\nEnter Remaining Resources Vector:\n";
    for(int i=0;i<r;i++)
        cin >> available[i];

    int s,q;
    for(int i=0;i<r;i++)
    {
        s=0;
        for(int j=0;j<p;j++)
            s+=allocated[j][i];
        resources[i]=s+available[i];
    }

    cout << "\nEnter number of Requests:\n";
    cin >> q;
    while(q--)
    {
        total=0;
        vector<int> safe;
        safe.clear();
        int allocatedN[P][R],maxN[P][R],resourcesN[R],availableN[R];
        bool marked[P];
        memset(marked, false, sizeof(marked));

        for(int i=0;i<p;i++)
            for(int j=0;j<r;j++)
                allocatedN[i][j]=allocated[i][j];
        for(int i=0;i<p;i++)
            for(int j=0;j<r;j++)
                maxN[i][j]=max[i][j];
        for(int i=0;i<r;i++)
                resourcesN[i]=resources[i];
        for(int i=0;i<r;i++)
                availableN[i]=available[i];

        int pN,rN[r];
        cout << "Enter Process ID with additional reuests for each resources:\n";
        cin >> pN;
        for(int i=0;i<r;i++)
            cin >> rN[i];

        int g=0;
        for(int i=0;i<r;i++)
        {
            allocatedN[pN][i]=rN[i];
            /*if(rN[i]>avialableN[i])
            {
                g=1;
                break;
            }*/
            availableN[i]-=(rN[i]-allocated[pN][i]);
            if(availableN[i]<0)
            {
                g=1;
                break;
            }
        }

        for(int i=0;i<p;i++)
        {
            for(int j=0;j<r;j++)
            {
                cout << allocatedN[i][j] << " ";
            }
            cout << endl;
        }
        cout << endl;

        if(g==1)
        {
            cout << "Request Cannot be permitted\n";
            continue;
        }

        int needN[P][R];
        for (int i = 0; i < p; i++)
            for (int j = 0; j < r; j++)
                needN[i][j] = ((maxN[i][j] - allocatedN[i][j])<0?0:(max[i][j] - allocated[i][j]));


        for(int i=0;i<p;i++)
        {
            for(int j=0;j<r;j++)
            {
                cout << needN[i][j] << " ";
            }
            cout << endl;
        }
        /*if(total==0)
        {
            cout << "Request Cannot be permitted\n";
            continue;
        }*/
        cout << "\nSafe sequences are:" << endl;
        safe_sequence(marked, allocatedN, maxN, needN, availableN, safe, p, r);

        cout << "\nThere are total " << total << " safe-sequences\n" << endl;
    }
    return 0;
}
