#!/bin/sh
echo "Number of Lines:"
read n
i=1
while [ $i -le $n ]
do
	j=1
	k=`expr $n - $i`
	x=1
	while [ $x -le $k ]
	do
		x=`expr $x + 1`
		echo " \c"
	done
	while [ $j -le $i ]
	do
		j=`expr $j + 1`
		echo "* \c"
	done
	echo ""
	i=`expr $i + 1`
done
