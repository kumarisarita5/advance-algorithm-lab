#include<bits/stdc++.h>
using namespace std;

int n,m;
bool check(int t,int l,vector<vector<int> > avail,vector<vector<int> > &need)
{
	int c = 0;
	for(int j=0;j<m;j++)
		if(avail[l][j]>=need[t][j])
			c++;
	if(c==4)
		return true;
	return false;
}	

void safeseq(int t,int l,vector<vector<int> >& alloc,vector<vector<int> > &req,vector<vector<int> > &need,vector<vector<int> > avail,vector<int> ans,vector<int> visit)
{
	visit[t] = true;
	bool f = check(t,l,avail,need);
	//cout<<t<<' '<<f<<endl;
	if(f)
		{ 
			for(int j=0;j<m;j++)
				avail[l+1][j] = avail[l][j] + alloc[t][j];
					
			ans.push_back(t);
			if(l+1==n)
				{
					for(int i=0;i<n;i++)
						cout<<ans[i]<<' ';
					cout<<endl;
					return;
				}
		}
	else
		return;
	for(int i=0;i<n;i++)		
		{
			if(!visit[i])
				{
					safeseq(i,l+1,alloc,req,need,avail,ans,visit);
				}
		}		
}				


int main()
{
	cin>>n>>m;
	vector<int> v(m);
	vector<vector<int> > alloc(n,v);
	vector<vector<int> > req(n,v);
	vector<vector<int> > need(n,v);
	vector<vector<int> > avail(n+1,v);
	vector<int> visit(n);
	vector<int> total(n);
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
			cin>>alloc[i][j];			
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
			cin>>req[i][j];
	for(int j=0;j<m;j++)
		cin>>total[j];
	for(int i=0;i<n;i++)
		{for(int j=0;j<m;j++)
			{
				need[i][j] = req[i][j] - alloc[i][j];
				//cout<<need[i][j]<<' ';
			}
		//cout<<endl;
		}
	//cout<<"avail"<<endl;
	vector<int> ans;
	for(int j=0;j<m;j++)
		{
			int t = 0;
			for(int i=0;i<n;i++)
				t = t + alloc[i][j];
			avail[0][j] = total[j] - t;
			//cout<<avail[0][j]<<' ';
		}
	//cout<<"ans"<<endl;
	for(int i=0;i<n;i++)			
		{
			//visit[i] = true;
			safeseq(i,0,alloc,req,need,avail,ans,visit);
			//visit[i] = false;
		}
}
/*
4 4
4 2 6 5
3 1 0 1
4 2 5 0
1 0 0 2
7 6 7 7
6 5 3 4
7 6 6 2
9 2 3 2
15 9 12 10
	*/
