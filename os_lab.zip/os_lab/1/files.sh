#!/bash/#!bin/sh
file1=$1
file2=$2
touch $file1
touch $file2
chmod u=wx $file1
chmod u=wx $file2

