#!/bash/#!/bin/sh
read n
a=1
b=1
c=2
echo $a
echo $b
echo $c

n=`expr $n - 3`
while [ $n -gt 0 ]
do
	d=`expr $a + $b + $c`
	echo $d
	a=$b
	b=$c
	c=$d
	n=`expr $n - 1`
done

