#!/bash/#!/bin/sh

while [ 1 -eq 1 ]
do
	read cmd
	case "$cmd" in 
		"dir")
		ls
		;;
	"cd")
		cd
		;;
	"rename")
		echo Enter old File name
		read f
		echo Enter new fiel name
		read n
		mv $f $n
		;;
	"del")
		echo Enter file name
		read f
		rm $f
		;;
	"copy")
		echo Enter source 
		read s
		echo Enter destination
		read d
		cp $s $d
		;;
	"exit")
		break
		;;
	*)
	echo no match
	;;
	esac
done


