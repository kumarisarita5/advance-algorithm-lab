#include <bits/stdc++.h>
using namespace std;
int id,artime,extime,qno,remtime,n,curtime,sumtat=0;
class pro{
public:
	int id,artime,extime,qno,remtime;
};
vector<pro> ar;
queue<pro> q[3];
int prono[10000];
bool comp(pro p1,pro p2){return p1.artime<p2.artime or (p1.artime==p2.artime and 				p1.id<p2.id);}
int main(){
	cout<<"Enter number of processes:\t";	cin>>n;
	for(int i=0;i<n;i++)
		cin>>id>>artime>>extime,
		ar.push_back({id,artime,extime,0,extime});
	sort(ar.begin(),ar.end(),comp);
	int cind=0,curtime=ar[0].artime;
	while(cind<n and ar[cind].artime<=curtime){
		q[0].push(ar[cind++]);
	}
	check:
	while(!q[0].empty()){
		pro p1=q[0].front();q[0].pop();
		if(p1.remtime<=4){
			for(int i=curtime;i<=curtime+p1.remtime;i++){
				prono[i]=p1.id;
			}
			curtime+=p1.remtime;
			p1.remtime=0;
			sumtat+=curtime-p1.artime;
		}
		else{
			for(int i=curtime;i<=curtime+4;i++){
				prono[i]=p1.id;
			}
			curtime+=4,
			p1.remtime-=4;
		}
		while(cind<n and ar[cind].artime<=curtime){
			q[0].push(ar[cind++]);
		}
		if(p1.remtime)
			q[1].push(p1);
	}
	while(!q[1].empty()){
		pro p1=q[1].front();q[1].pop();
		if(p1.remtime<=8){
			for(int i=curtime;i<=curtime+p1.remtime;i++){
				prono[i]=p1.id;
			}
			curtime+=p1.remtime;
			p1.remtime=0;
			sumtat+=curtime-p1.artime;
		}
		else{
			for(int i=curtime;i<=curtime+8;i++){
				prono[i]=p1.id;
			}
			curtime+=8,
			p1.remtime-=8;
		}
		if(p1.remtime)
			q[2].push(p1);
		while(cind<n and ar[cind].artime<=curtime){
			q[0].push(ar[cind++]);
		}
		goto check;
	}
	while(!q[2].empty()){
		pro p1=q[2].front();q[2].pop();
		if(p1.remtime<=12){
			for(int i=curtime;i<=p1.remtime+curtime;i++){
				prono[i]=p1.id;
			}
			curtime+=p1.remtime;
			p1.remtime=0;
			sumtat+=curtime-p1.artime;
		}
		else{
			for(int i=curtime;i<=12+curtime;i++){
				prono[i]=p1.id;
			}
			curtime+=8,
			p1.remtime-=8;
		}
		if(p1.remtime)
			q[2].push(p1);
		while(cind<n and ar[cind].artime<=curtime){
			q[0].push(ar[cind++]);
		}
		goto check;
	}
	if(cind<n){
		curtime=ar[cind].artime;
		q[0].push(ar[cind++]);
		goto check;
	}
	for(int i=ar[0].artime;i<=curtime;i++){
		cout<<"process"<<" "<<prono[i]<<" executed at "<<i<<endl;
	}
	cout<<(double)sumtat/(double)n<<endl;
}
//id>>artime>>extime

/*
7
1 0 4
2 0 3
3 2 7
4 4 9
5 3 14
6 1 8
7 10 22

5
1 0 10
2 2 5
3 9 2
4 20 15
5 18 6

*/
