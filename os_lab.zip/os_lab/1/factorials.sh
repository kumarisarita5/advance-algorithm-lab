#!/bin/bash
read n
ans=1
while [ $n -ge 1 ];
do
	ans=`expr $n \* $ans`
	n=`expr $n - 1`
done
echo "$ans"
