#!/bash/#/!bin/sh
i=1
j=1
while [ $i -le 4 ];
do
	j=0
	while [ $j -lt $i ];
	do
		echo -n \*
		j=`expr $j + 1`
	done
	echo
	i=`expr $i + 1`
done



