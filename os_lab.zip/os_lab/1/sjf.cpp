#include<bits/stdc++.h>
using namespace std;
struct ptime
{
    int pid;
    int atime;
    int btime;
};
bool compare(ptime p1,ptime p2)
{
    if(p1.atime==p2.atime) 
            return bool(p1.btime<p2.btime);
    else return bool(p1.atime<p2.atime);
}
void fcfs(ptime P[],int n)
{
    sort(P+1,P+n,compare);int t=0;
    int tat[n+1];int ctat=0;
    for(int i=1;i<n+1;i++)
    {
        if(t>=P[i].atime)
        {
            t+=P[i].btime;
            tat[i]=t-P[i].atime;
            ctat+=tat[i];
        }    
        else
        t++;
    }
    for(int i=1;i<n+1;i++)
    {
        cout<<"Pid:\t"<<P[i].pid<<" Arrival:\t"<<P[i].atime<<" burst time:\t"<<P[i].btime<<" tat:\t"<<tat[i]<<"\n";
    }
    cout<<(float)ctat/n<<endl;
}
int main()
{
    int n;
    cout<<"enter the no. of processes:";
    cin>>n;
    ptime P[n+1];
    for(int i=1;i<n+1;i++)
    {
        P[i].pid=i;
        cin>>P[i].atime>>P[i].btime;
    }
    fcfs(P,n);
}
