#include<iostream>
using namespace std;

struct node
{
	int a;
	node* next;
	node(int b = 0)
	{
		a = b;
		next = NULL;
	}
};
int c = 0;
int n;
node* head = new node;
void Produce(int x)
{
	if(c==n)
		{
			cout<<"F"<<endl;
			return;   
		}
	c++;
	node* itr = head;
	while(itr->next!=head)
		itr = itr->next;
	node* ptr = new node(x);
	ptr->next = itr->next;
	itr->next = ptr;
}
void Consume()
{
	if(c==0)
		{
			cout<<"E"<<endl;
			return;
		}
	c--;
	cout<<"consumed item"<<head->next->a<<endl;
	head->next = head->next->next;
	return;
}
int main()
{
//	int n;
	cout<<"Enter the size of the buffer"<<endl;
	cin>>n;
	head->next = head;
	while(true)
	{
		int t;
		cout<<"1.Produce"<<endl;
		cout<<"2.consumer"<<endl;
		cout<<"3.Exit"<<endl;
		cin>>t;
		int x;
		switch(t)
		{
			case 1:{ 
						cout<<"Enter the key of product to be produced"<<endl;
						cin>>x;
						Produce(x);
						break;
					}
			case 2:{
						Consume();
						break;
					}
			case 3: return 0;
		}
				
	}

}
