#include<bits/stdc++.h>
using namespace std;
#define N 10

struct semaphore{
        set<int> q;
};

bool empty(semaphore &s){
        return s.q.size()==0;
}

bool full(semaphore &s){
        return s.q.size()==N;
}

void arrive(semaphore &s,int id){
        if(full(s))
                cout<<"Waiting area full\n";
        else
                s.q.insert(id);
        
        if(s.q.size()==1)
                cout<<"Professor awakes\n";
}

void depart(semaphore &s,int id){
        if(s.q.find(id)!=s.q.end()){
                s.q.erase(s.q.find(id));
                if(empty(s))
                        cout<<"Professor sleeps\n";
        }
}

int main(){
        cout<<"1. Student arrives\n2. Student leaves\n3. Exit\n";
        int n,id;
        semaphore s;
        while(1){
                cout<<"Enter choice\n";
                cin>>n;
                if(n==1){
                        cout<<"Enter id\n";
                        cin>>id;
                        arrive(s,id);
                }else if(n==2){
                        cout<<"Enter id\n";
                        cin>>id;
                        depart(s,id);
                }else
                        break;
        }
}

