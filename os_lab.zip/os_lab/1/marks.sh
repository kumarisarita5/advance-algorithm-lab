#!/bin/bash
read m
if [ $m -ge 90 ] && [ $m -le 100 ];then
	echo "A"
elif [ $m -ge 70 ] && [ $m -le 89 ];then
	echo "B"
elif [ $m -ge 40 ] && [ $m -le 69 ];then
	echo "C"
else
	echo "F"
fi

