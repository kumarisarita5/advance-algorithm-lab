﻿#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main () {
  string line,s;
  cin>>s;
  int k=0;
  ifstream myfile ("bing.txt");
  myfile.is_open();
    while(1)
    {
        myfile>>line;
        if(line=="\n")break;
        if(line==s)k++;
    }
    myfile.close();
    cout<<k<<endl;
  return 0;
}
